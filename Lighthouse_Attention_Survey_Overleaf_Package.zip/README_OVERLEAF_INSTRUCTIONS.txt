Lighthouse Attention Survey - Overleaf Package

Files included:
1. lighthouse_attention_survey_neurips.tex
2. survey_references.bib

How to use in Overleaf:
1. Upload this ZIP to Overleaf.
2. Make sure the official neurips_2026.sty file is present in the same project.
3. Set lighthouse_attention_survey_neurips.tex as the Main file.
4. Click Recompile.
5. Download the generated PDF.

Notes:
- This package is generated from Lighthouse_Attention_Survey_Draft.docx.
- The submission version is anonymous by default.
- To make a preprint/internal version, replace \usepackage{neurips_2026} with \usepackage[preprint]{neurips_2026} and update the author block.
