# Shortened Anonymous CSUR Package

This version shortens multiple sections by approximately 3-4+ lines and keeps the manuscript anonymous.
It also compacts the bibliography to avoid a final page containing only one reference line.

Compile `main.tex` in Overleaf with pdfLaTeX.
