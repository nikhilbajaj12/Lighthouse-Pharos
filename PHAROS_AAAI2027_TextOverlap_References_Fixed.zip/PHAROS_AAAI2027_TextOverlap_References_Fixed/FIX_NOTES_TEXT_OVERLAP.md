# PHAROS AAAI2027 Text-Overlap and Reference Fix

This package fixes the issue where text in the reference section, especially the Vaswani reference, may overlap or run into another paragraph.

Changes applied:
1. `main.tex` uses your style files:
   - `\usepackage{aaai2027}`
   - `\bibliographystyle{aaai2027}`
2. Added layout-safe line breaking:
   - `\usepackage[T1]{fontenc}`
   - `\usepackage{microtype}`
   - `\sloppy`
   - `\emergencystretch=3em`
   - `\raggedbottom`
3. Shortened long BibTeX author lists using `and others`, especially `vaswani2017attention`, to prevent collision/overlap.
4. Added real citations in the text and retained:
   - `\nocite{*}`
   - `\bibliography{references}`

Overleaf must contain all these files in the same folder:
- `main.tex`
- `references.bib`
- `aaai2027.sty`
- `aaai2027.bst`

After replacing files:
1. Clear cached files.
2. Recompile from scratch.
3. If still overlapping, check whether your uploaded `aaai2027.bst` is actually named exactly `aaai2027.bst`.
