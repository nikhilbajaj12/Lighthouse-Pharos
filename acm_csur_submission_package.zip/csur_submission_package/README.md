
# ACM CSUR Submission Package

This package is prepared for **Option A: ACM Computing Surveys (CSUR)**.

Files:
- `main.tex` — Overleaf-ready LaTeX draft
- `references.bib` — references
- `cover_letter.txt` — editable cover letter template
- `submission_checklist.md` — practical final checklist

Compile on Overleaf:
1. Upload the ZIP as a new Overleaf project.
2. Use `main.tex` as the main file.
3. Compile with pdfLaTeX.
