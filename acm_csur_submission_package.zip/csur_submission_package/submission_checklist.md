
# CSUR Submission Checklist

Before submitting:

- [ ] Replace `Anonymous for Submission` with real author details if submitting non-anonymously.
- [ ] Expand the current draft toward a fuller survey scope (CSUR normally expects comprehensive synthesis).
- [ ] Add a proper literature collection methodology / survey protocol section.
- [ ] Add comparison tables and broader literature coverage.
- [ ] Ensure the manuscript is not just a literature review but has a genuine organizing framework.
- [ ] Check recent CSUR/related surveys for overlap before final submission.
- [ ] Confirm formatting in `acmart` compiles cleanly on Overleaf.
- [ ] Prepare final cover letter.
