# CSUR Ready LaTeX Package With Authors

Authors added:
- Saipriyadarshan Cindula*
- Nikhil Gajanan Bajaj*

Affiliation: ZenLabs, Zensar Technologies
Emails: {saipriyadarshan.cindula, nikhil.bajaj}@zensar.com

* Equal contribution.

Compile `main.tex` on Overleaf with pdfLaTeX. Before final submission, verify all references.
