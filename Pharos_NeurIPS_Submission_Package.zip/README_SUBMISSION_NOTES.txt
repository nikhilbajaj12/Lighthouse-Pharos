PHAROS NeurIPS 2026 Submission Package

Files:
1. pharos_neurips_2026_submission.tex
2. references.bib

Important submission notes:
- Place the official neurips_2026.sty file in the same folder before compiling.
- This version is anonymized for review.
- No fabricated quantitative numbers are included.
- Results are marked as pending reproducibility validation.
- Before final submission, fill the official NeurIPS checklist as required by the current NeurIPS instructions.
- If real experiments are completed, replace the placeholder tables with verified numbers only.

Recommended compile command:
pdflatex pharos_neurips_2026_submission.tex
bibtex pharos_neurips_2026_submission
pdflatex pharos_neurips_2026_submission.tex
pdflatex pharos_neurips_2026_submission.tex
