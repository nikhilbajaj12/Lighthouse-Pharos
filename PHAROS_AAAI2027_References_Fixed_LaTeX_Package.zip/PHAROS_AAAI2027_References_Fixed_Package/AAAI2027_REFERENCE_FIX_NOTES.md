# PHAROS AAAI-2027 References Fixed Package

This package is updated for the files you have:
- `aaai2027.sty`
- `aaai2027.bst`

Important changes:
1. `main.tex` now uses `\usepackage{aaai2027}`.
2. `supplementary.tex` now uses `\usepackage{aaai2027}`.
3. References are fixed using both real `\cite{...}` commands in the text and:

```latex
\nocite{*}
\bibliographystyle{aaai2027}
\bibliography{references}
```

Overleaf file list must contain:
- `main.tex`
- `references.bib`
- `aaai2027.sty`
- `aaai2027.bst`

If references still do not show:
1. Menu -> Recompile from scratch.
2. Logs and output files -> Clear cached files.
3. Recompile again.
4. Make sure `references.bib` is in the same folder as `main.tex`.
