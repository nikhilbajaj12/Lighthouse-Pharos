
# Anonymous CSUR LaTeX Package — Last Page Fix

Changes made:
1. Kept manuscript anonymous using `anonymous` option in `acmart`.
2. Removed author names/emails from the title block.
3. Removed long "Reference placeholder; verify before final submission" notes that caused bibliography overflow.
4. Added compact bibliography formatting to avoid a final page with only one reference line.
5. Kept review/manuscript mode for ACM CSUR.

Compile with pdfLaTeX on Overleaf.
If your local Overleaf output still creates a one-line final page due to engine/version differences, reduce only reference spacing or add one more line to the conclusion; do not add fake content.
