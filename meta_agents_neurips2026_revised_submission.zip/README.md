# Meta-Agents Workshop 2026 — Revised Double-Blind Submission Package

## Ready configuration
- `main.tex` uses `\usepackage[dblblindworkshop]{neurips_2026}`.
- Workshop title is set to `Managing Agents that Manage Agents`.
- Review PDF is anonymous and includes line numbers.
- Responsible-Use Statement is included.
- References and appendix follow the main paper.

## Compile in Overleaf
1. Upload this ZIP as a new project.
2. Set `main.tex` as the main document.
3. Select pdfLaTeX.
4. Use **Recompile from scratch**.
5. Upload only the generated anonymous `main.pdf` to OpenReview.

## Final checks
Confirm that the main text, including the Responsible-Use Statement, is at most 9 pages; references and appendix are excluded. Confirm that no author identity appears in the PDF or PDF metadata and that all citations are resolved.
